import { useState, useEffect } from 'react';
import { supabase, type Recipe, MEAL_TYPES } from '../lib/supabase';
import { NutritionFacts } from '../components/NutritionFacts';
import { CookingTimer } from '../components/CookingTimer';
import { showToast } from '../components/Toast';
import { Modal } from '../components/Modal';
import {
  ArrowLeft, Clock, Users, Flame, ChefHat, Play, Heart,
  Timer as TimerIcon, Video, ShoppingCart, Calendar, Sparkles
} from 'lucide-react';

type RecipeDetailProps = {
  recipe: Recipe;
  onBack: () => void;
  onOpenRecipe: (recipe: Recipe) => void;
};

export function RecipeDetail({ recipe, onBack }: RecipeDetailProps) {
  const [servings, setServings] = useState(recipe.servings);
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [showVideo, setShowVideo] = useState(false);
  const [showAddToPlan, setShowAddToPlan] = useState(false);
  const [planDate, setPlanDate] = useState(new Date().toISOString().split('T')[0]);
  const [planMeal, setPlanMeal] = useState<string>('dinner');
  const [isSaved, setIsSaved] = useState(recipe.source === 'curated');

  useEffect(() => {
    setServings(recipe.servings);
    setActiveStep(null);
    setIsSaved(recipe.source === 'curated');
  }, [recipe]);

  const totalTime = recipe.prep_time_min + recipe.cook_time_min;
  const servingRatio = servings / recipe.servings;

  const handleAddToPlan = async () => {
    const { error } = await supabase.from('meal_plans').insert({
      plan_date: planDate,
      meal_type: planMeal,
      recipe_id: recipe.id,
      servings,
    });
    if (error) {
      showToast('Failed to add to meal plan', 'error');
      return;
    }
    showToast('Added to meal plan');
    setShowAddToPlan(false);
  };

  const handleAddToGrocery = async () => {
    const items = recipe.ingredients.map(ing => ({
      name: ing.name,
      quantity: ing.amount,
      unit: ing.unit,
      category: 'Other',
      checked: false,
      recipe_id: recipe.id,
    }));
    const { error } = await supabase.from('grocery_items').insert(items);
    if (error) {
      showToast('Failed to add to grocery list', 'error');
      return;
    }
    showToast('Ingredients added to grocery list');
  };

  const handleSaveRecipe = async () => {
    if (isSaved) return;
    const { id, ...rest } = recipe;
    const { error } = await supabase.from('recipes').insert({ ...rest, source: 'ai' });
    if (error) {
      showToast('Failed to save recipe', 'error');
      return;
    }
    setIsSaved(true);
    showToast('Recipe saved to your collection');
  };

  const youtubeEmbedUrl = recipe.video_url
    ? recipe.video_url.replace('youtube.com/embed/', 'youtube.com/embed/') + '?rel=0'
    : null;

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-neutral-500 hover:text-neutral-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl h-72 lg:h-96">
        {recipe.image_url && (
          <img src={recipe.image_url} alt={recipe.title} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
          <div className="flex items-center gap-2 mb-3">
            {recipe.source === 'ai' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-warm text-white">
                <Sparkles className="w-3 h-3" /> AI Generated
              </span>
            )}
            <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-white/20 backdrop-blur-sm text-white">{recipe.cuisine}</span>
            <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
              recipe.difficulty === 'Easy' ? 'bg-success-500/80 text-white' :
              recipe.difficulty === 'Medium' ? 'bg-warning-500/80 text-white' :
              'bg-error-500/80 text-white'
            }`}>{recipe.difficulty}</span>
          </div>
          <h1 className="font-display text-2xl lg:text-4xl font-bold text-white text-balance">{recipe.title}</h1>
          <p className="mt-2 text-neutral-200 text-sm lg:text-base max-w-2xl">{recipe.description}</p>
        </div>
      </div>

      {/* Quick stats bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatBox icon={Clock} label="Total Time" value={`${totalTime} min`} sub={`${recipe.prep_time_min} prep · ${recipe.cook_time_min} cook`} color="text-primary-600" bg="bg-primary-50" />
        <StatBox icon={Users} label="Servings" value={String(servings)} sub="adjustable" color="text-secondary-600" bg="bg-secondary-50" />
        <StatBox icon={Flame} label="Calories" value={`${Math.round(recipe.nutrition?.calories * servingRatio || 0)}`} sub="per serving" color="text-accent-600" bg="bg-accent-50" />
        <StatBox icon={ChefHat} label="Difficulty" value={recipe.difficulty} sub={recipe.cuisine} color="text-warning-600" bg="bg-warning-50" />
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setShowAddToPlan(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 text-neutral-700 font-medium hover:border-primary-300 hover:text-primary-700 transition-all"
        >
          <Calendar className="w-4 h-4" />
          Add to Meal Plan
        </button>
        <button
          onClick={handleAddToGrocery}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 text-neutral-700 font-medium hover:border-secondary-300 hover:text-secondary-700 transition-all"
        >
          <ShoppingCart className="w-4 h-4" />
          Add Ingredients to Grocery
        </button>
        {recipe.video_url && (
          <button
            onClick={() => setShowVideo(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 text-neutral-700 font-medium hover:border-accent-300 hover:text-accent-700 transition-all"
          >
            <Video className="w-4 h-4" />
            Watch Tutorial
          </button>
        )}
        {!isSaved && (
          <button
            onClick={handleSaveRecipe}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all"
          >
            <Heart className="w-4 h-4" />
            Save Recipe
          </button>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left — ingredients + nutrition */}
        <div className="lg:col-span-1 space-y-6">
          {/* Ingredients */}
          <div className="bg-white rounded-2xl border border-neutral-200 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg font-bold text-neutral-900">Ingredients</h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setServings(Math.max(1, servings - 1))}
                  className="w-7 h-7 rounded-lg bg-neutral-100 text-neutral-600 hover:bg-neutral-200 flex items-center justify-center text-sm font-bold"
                >−</button>
                <span className="text-sm font-semibold text-neutral-700 w-8 text-center">{servings}</span>
                <button
                  onClick={() => setServings(servings + 1)}
                  className="w-7 h-7 rounded-lg bg-neutral-100 text-neutral-600 hover:bg-neutral-200 flex items-center justify-center text-sm font-bold"
                >+</button>
              </div>
            </div>
            <ul className="space-y-2.5">
              {recipe.ingredients.map((ing, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary-400 shrink-0" />
                  <span className="text-neutral-700 flex-1">{ing.name}</span>
                  <span className="text-neutral-400 text-xs font-medium shrink-0">
                    {scaleAmount(ing.amount, servingRatio)} {ing.unit}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Nutrition */}
          {recipe.nutrition && (
            <NutritionFacts nutrition={recipe.nutrition} servings={servingRatio} />
          )}
        </div>

        {/* Right — instructions + timer */}
        <div className="lg:col-span-2 space-y-6">
          {/* Cooking timer */}
          {activeStep !== null && recipe.instructions[activeStep]?.timer_min && (
            <CookingTimer
              initialMinutes={recipe.instructions[activeStep].timer_min}
              label={`Step ${activeStep + 1} Timer`}
              onClose={() => setActiveStep(null)}
            />
          )}

          {/* Instructions */}
          <div className="bg-white rounded-2xl border border-neutral-200 p-5">
            <h2 className="font-display text-lg font-bold text-neutral-900 mb-4">Instructions</h2>
            <ol className="space-y-4">
              {recipe.instructions.map((inst, i) => (
                <li
                  key={i}
                  className={`flex gap-4 p-3 rounded-xl transition-all ${
                    activeStep === i ? 'bg-primary-50 border border-primary-200' : 'hover:bg-neutral-50'
                  }`}
                >
                  <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                    activeStep === i ? 'bg-gradient-warm text-white' : 'bg-neutral-100 text-neutral-600'
                  }`}>
                    {inst.step}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-neutral-700 leading-relaxed">{inst.text}</p>
                    {inst.timer_min && (
                      <button
                        onClick={() => setActiveStep(activeStep === i ? null : i)}
                        className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-neutral-100 text-neutral-700 hover:bg-primary-100 hover:text-primary-700 transition-colors"
                      >
                        <TimerIcon className="w-3.5 h-3.5" />
                        {activeStep === i ? 'Hide Timer' : `Start ${inst.timer_min} min Timer`}
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          </div>

          {/* Video tutorial preview */}
          {recipe.video_url && (
            <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden">
              <div className="p-5">
                <h2 className="font-display text-lg font-bold text-neutral-900 mb-1 flex items-center gap-2">
                  <Video className="w-5 h-5 text-accent-600" />
                  Video Tutorial
                </h2>
                <p className="text-sm text-neutral-500 mb-4">Watch and learn the cooking techniques for this recipe.</p>
              </div>
              <div className="relative aspect-video bg-neutral-900 cursor-pointer group" onClick={() => setShowVideo(true)}>
                <img
                  src={`https://img.youtube.com/vi/${getYoutubeId(recipe.video_url)}/hqdefault.jpg`}
                  alt="Video thumbnail"
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center group-hover:scale-110 group-hover:bg-white transition-all shadow-large">
                    <Play className="w-7 h-7 text-error-600 ml-1" fill="currentColor" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Video modal */}
      <Modal open={showVideo} onClose={() => setShowVideo(false)} size="xl" title="Cooking Tutorial">
        <div className="aspect-video rounded-xl overflow-hidden bg-neutral-900">
          {youtubeEmbedUrl && (
            <iframe
              src={youtubeEmbedUrl}
              title="Cooking tutorial"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          )}
        </div>
      </Modal>

      {/* Add to plan modal */}
      <Modal open={showAddToPlan} onClose={() => setShowAddToPlan(false)} title="Add to Meal Plan">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">Date</label>
            <input
              type="date"
              value={planDate}
              onChange={e => setPlanDate(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">Meal</label>
            <div className="grid grid-cols-4 gap-2">
              {MEAL_TYPES.map(m => (
                <button
                  key={m}
                  onClick={() => setPlanMeal(m)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                    planMeal === m ? 'bg-gradient-warm text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={handleAddToPlan}
            className="w-full py-2.5 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all"
          >
            Add to Plan
          </button>
        </div>
      </Modal>
    </div>
  );
}

function StatBox({ icon: Icon, label, value, sub, color, bg }: any) {
  return (
    <div className="bg-white rounded-2xl border border-neutral-200 p-4">
      <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center mb-2`}>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <div className="text-xs text-neutral-400">{label}</div>
      <div className="text-lg font-bold text-neutral-900 font-display">{value}</div>
      <div className="text-xs text-neutral-400">{sub}</div>
    </div>
  );
}

function scaleAmount(amount: string, ratio: number): string {
  const parsed = parseFloat(amount);
  if (isNaN(parsed)) return amount;
  const scaled = parsed * ratio;
  return scaled % 1 === 0 ? String(scaled) : scaled.toFixed(2).replace(/\.?0+$/, '');
}

function getYoutubeId(url: string | null): string {
  if (!url) return '';
  const match = url.match(/embed\/([\w-]+)/);
  return match ? match[1] : '';
}
