import { useState } from 'react';
import { CookingTimer } from '../components/CookingTimer';
import { Timer, Plus, Egg, Flame, Soup, Croissant } from 'lucide-react';

const PRESETS = [
  { label: 'Soft Boiled Egg', minutes: 6, icon: Egg, color: 'bg-warning-100 text-warning-700' },
  { label: 'Hard Boiled Egg', minutes: 10, icon: Egg, color: 'bg-error-100 text-error-700' },
  { label: 'Al Dente Pasta', minutes: 9, icon: Soup, color: 'bg-primary-100 text-primary-700' },
  { label: 'Rice', minutes: 18, icon: Soup, color: 'bg-secondary-100 text-secondary-700' },
  { label: 'Searing Steak', minutes: 4, icon: Flame, color: 'bg-error-100 text-error-700' },
  { label: 'Proofing Dough', minutes: 60, icon: Croissant, color: 'bg-accent-100 text-accent-700' },
  { label: 'Blanching Veg', minutes: 3, icon: Soup, color: 'bg-success-100 text-success-700' },
  { label: 'Simmering Sauce', minutes: 30, icon: Flame, color: 'bg-primary-100 text-primary-700' },
];

type ActiveTimer = {
  id: string;
  minutes: number;
  label: string;
};

export function CookingTimers() {
  const [timers, setTimers] = useState<ActiveTimer[]>([
    { id: '1', minutes: 10, label: 'Cooking Timer' },
  ]);
  const [customMinutes, setCustomMinutes] = useState(15);
  const [customLabel, setCustomLabel] = useState('');

  const addTimer = (minutes: number, label: string) => {
    const id = crypto.randomUUID();
    setTimers(prev => [...prev, { id, minutes, label }]);
  };

  const removeTimer = (id: string) => {
    setTimers(prev => prev.filter(t => t.id !== id));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="font-display text-2xl lg:text-3xl font-bold text-neutral-900 flex items-center gap-2">
          <Timer className="w-6 h-6 text-primary-600" />
          Cooking Timers
        </h1>
        <p className="text-neutral-500 mt-1">Never overcook again. Run multiple timers simultaneously.</p>
      </div>

      {/* Presets */}
      <div className="bg-white rounded-2xl border border-neutral-200 p-5">
        <h2 className="font-display text-lg font-bold text-neutral-900 mb-4">Quick Start Presets</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {PRESETS.map(preset => {
            const Icon = preset.icon;
            return (
              <button
                key={preset.label}
                onClick={() => addTimer(preset.minutes, preset.label)}
                className="group flex flex-col items-center gap-2 p-4 rounded-xl border border-neutral-200 hover:border-primary-300 hover:shadow-soft transition-all"
              >
                <div className={`w-11 h-11 rounded-xl ${preset.color} flex items-center justify-center`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-neutral-800">{preset.label}</p>
                  <p className="text-xs text-neutral-400 mt-0.5">{preset.minutes} min</p>
                </div>
                <Plus className="w-4 h-4 text-neutral-300 group-hover:text-primary-500 transition-colors" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom timer creator */}
      <div className="bg-white rounded-2xl border border-neutral-200 p-5">
        <h2 className="font-display text-lg font-bold text-neutral-900 mb-4">Custom Timer</h2>
        <div className="flex flex-col sm:flex-row gap-3 items-end">
          <div className="flex-1 w-full">
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Label (optional)</label>
            <input
              value={customLabel}
              onChange={e => setCustomLabel(e.target.value)}
              placeholder="e.g., Baking cookies"
              className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
          <div className="w-full sm:w-32">
            <label className="block text-xs font-medium text-neutral-500 mb-1.5">Minutes</label>
            <input
              type="number"
              min="1"
              max="999"
              value={customMinutes}
              onChange={e => setCustomMinutes(Math.max(1, Math.min(999, Number(e.target.value))))}
              className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
          <button
            onClick={() => addTimer(customMinutes, customLabel || `Timer ${timers.length + 1}`)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Add Timer
          </button>
        </div>
      </div>

      {/* Active timers */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-neutral-900">
            Active Timers <span className="text-neutral-400 font-normal">({timers.length})</span>
          </h2>
          {timers.length > 0 && (
            <button
              onClick={() => setTimers([])}
              className="text-sm text-neutral-400 hover:text-error-600 font-medium"
            >
              Clear All
            </button>
          )}
        </div>
        {timers.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-neutral-200">
            <Timer className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
            <p className="text-sm text-neutral-400">No active timers. Add one from the presets above.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {timers.map(timer => (
              <CookingTimer
                key={timer.id}
                initialMinutes={timer.minutes}
                label={timer.label}
                onClose={() => removeTimer(timer.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
