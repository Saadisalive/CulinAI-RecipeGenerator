import { useState, useEffect } from 'react';
import { supabase, type Recipe, type MealPlan, MEAL_TYPES } from '../lib/supabase';
import { showToast } from '../components/Toast';
import { Modal } from '../components/Modal';
import {
  ChevronLeft, ChevronRight, Plus, Clock, Users, Trash2,
  Calendar, Utensils, Sun, Moon, Coffee, Cookie
} from 'lucide-react';

type MealPlannerProps = {
  onOpenRecipe: (recipe: Recipe) => void;
};

type PlanWithRecipe = MealPlan & { recipes: Recipe | null };

const MEAL_ICONS: Record<string, any> = {
  breakfast: Coffee, lunch: Sun, dinner: Moon, snack: Cookie,
};

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function MealPlanner({ onOpenRecipe }: MealPlannerProps) {
  const [weekStart, setWeekStart] = useState(getWeekStart(new Date()));
  const [plans, setPlans] = useState<PlanWithRecipe[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [addDate, setAddDate] = useState('');
  const [addMeal, setAddMeal] = useState('dinner');
  const [addRecipeId, setAddRecipeId] = useState('');

  useEffect(() => { loadRecipes(); }, []);
  useEffect(() => { loadPlans(); }, [weekStart]);

  const loadRecipes = async () => {
    const { data } = await supabase.from('recipes').select('*').order('title');
    if (data) setRecipes(data as Recipe[]);
  };

  const loadPlans = async () => {
    setLoading(true);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 7);
    const { data } = await supabase
      .from('meal_plans')
      .select('*, recipes(*)')
      .gte('plan_date', weekStart.toISOString().split('T')[0])
      .lt('plan_date', weekEnd.toISOString().split('T')[0])
      .order('plan_date')
      .order('meal_type');
    if (data) setPlans(data as PlanWithRecipe[]);
    setLoading(false);
  };

  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    return d;
  });

  const getPlansForDay = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return plans.filter(p => p.plan_date === dateStr);
  };

  const handleAdd = async () => {
    if (!addRecipeId) {
      showToast('Select a recipe', 'error');
      return;
    }
    const { error } = await supabase.from('meal_plans').insert({
      plan_date: addDate,
      meal_type: addMeal,
      recipe_id: addRecipeId,
      servings: 1,
    });
    if (error) {
      showToast('Failed to add meal', 'error');
      return;
    }
    showToast('Meal added to plan');
    setShowAdd(false);
    loadPlans();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('meal_plans').delete().eq('id', id);
    setPlans(prev => prev.filter(p => p.id !== id));
    showToast('Meal removed');
  };

  const openAddModal = (date: Date, meal?: string) => {
    setAddDate(date.toISOString().split('T')[0]);
    setAddMeal(meal || 'dinner');
    setAddRecipeId('');
    setShowAdd(true);
  };

  const navigateWeek = (direction: number) => {
    const newStart = new Date(weekStart);
    newStart.setDate(newStart.getDate() + direction * 7);
    setWeekStart(newStart);
  };

  const weekLabel = `${weekDays[0].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} – ${weekDays[6].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-neutral-900 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-primary-600" />
            Meal Planner
          </h1>
          <p className="text-neutral-500 mt-1">Plan your week, one meal at a time.</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => navigateWeek(-1)} className="p-2 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-50">
            <ChevronLeft className="w-5 h-5 text-neutral-600" />
          </button>
          <span className="font-semibold text-neutral-900 min-w-[140px] text-center">{weekLabel}</span>
          <button onClick={() => navigateWeek(1)} className="p-2 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-50">
            <ChevronRight className="w-5 h-5 text-neutral-600" />
          </button>
        </div>
      </div>

      {/* Week grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4">
        {weekDays.map((date, i) => {
          const dayPlans = getPlansForDay(date);
          const isToday = date.toISOString().split('T')[0] === new Date().toISOString().split('T')[0];
          return (
            <div key={i} className={`bg-white rounded-2xl border ${isToday ? 'border-primary-300 shadow-soft' : 'border-neutral-200'} overflow-hidden`}>
              <div className={`px-3 py-2.5 border-b ${isToday ? 'bg-primary-50 border-primary-200' : 'bg-neutral-50 border-neutral-200'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-medium text-neutral-400">{WEEKDAYS[date.getDay()]}</span>
                    <span className={`ml-1.5 text-sm font-bold ${isToday ? 'text-primary-700' : 'text-neutral-900'}`}>
                      {date.getDate()}
                    </span>
                  </div>
                  {isToday && <span className="text-xs text-primary-600 font-medium">Today</span>}
                </div>
              </div>
              <div className="p-2 space-y-2 min-h-[200px]">
                {MEAL_TYPES.map(meal => {
                  const plan = dayPlans.find(p => p.meal_type === meal);
                  const Icon = MEAL_ICONS[meal];
                  return (
                    <div key={meal}>
                      {plan && plan.recipes ? (
                        <div
                          className="group relative rounded-lg overflow-hidden cursor-pointer hover:shadow-soft transition-all"
                          onClick={() => onOpenRecipe(plan.recipes!)}
                        >
                          <div className="relative h-16 overflow-hidden">
                            {plan.recipes.image_url && (
                              <img src={plan.recipes.image_url} alt="" className="w-full h-full object-cover" />
                            )}
                            <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/80 to-neutral-900/20" />
                            <div className="absolute bottom-0 left-0 right-0 p-1.5">
                              <div className="flex items-center gap-1 mb-0.5">
                                <Icon className="w-3 h-3 text-white/80" />
                                <span className="text-[10px] text-white/70 capitalize">{meal}</span>
                              </div>
                              <p className="text-xs font-semibold text-white line-clamp-1">{plan.recipes.title}</p>
                            </div>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDelete(plan.id); }}
                            className="absolute top-1 right-1 p-1 rounded bg-neutral-900/40 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => openAddModal(date, meal)}
                          className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs text-neutral-400 hover:bg-neutral-50 hover:text-neutral-600 transition-colors"
                        >
                          <Icon className="w-3 h-3" />
                          <span className="capitalize">{meal}</span>
                          <Plus className="w-3 h-3 ml-auto" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      {!loading && plans.length > 0 && (
        <div className="bg-white rounded-2xl border border-neutral-200 p-5">
          <h3 className="font-display text-lg font-bold text-neutral-900 mb-3 flex items-center gap-2">
            <Utensils className="w-5 h-5 text-primary-600" />
            This Week's Summary
          </h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <SummaryStat label="Meals Planned" value={plans.length} />
            <SummaryStat label="Breakfasts" value={plans.filter(p => p.meal_type === 'breakfast').length} />
            <SummaryStat label="Lunches" value={plans.filter(p => p.meal_type === 'lunch').length} />
            <SummaryStat label="Dinners" value={plans.filter(p => p.meal_type === 'dinner').length} />
          </div>
        </div>
      )}

      {/* Empty state hint */}
      {!loading && plans.length === 0 && (
        <div className="text-center py-8">
          <p className="text-sm text-neutral-400">No meals planned for this week yet. Click the + buttons above to start planning.</p>
        </div>
      )}

      {/* Add meal modal */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title={`Add Meal · ${new Date(addDate).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}`}>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">Meal Type</label>
            <div className="grid grid-cols-4 gap-2">
              {MEAL_TYPES.map(m => {
                const Icon = MEAL_ICONS[m];
                return (
                  <button
                    key={m}
                    onClick={() => setAddMeal(m)}
                    className={`flex flex-col items-center gap-1 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                      addMeal === m ? 'bg-gradient-warm text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {m}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">Recipe</label>
            <select
              value={addRecipeId}
              onChange={e => setAddRecipeId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
            >
              <option value="">Select a recipe...</option>
              {recipes.map(r => (
                <option key={r.id} value={r.id}>{r.title} · {r.cuisine}</option>
              ))}
            </select>
          </div>
          {addRecipeId && (
            <div className="p-3 rounded-xl bg-neutral-50 flex items-center gap-3">
              {(() => {
                const r = recipes.find(r => r.id === addRecipeId);
                return r ? (
                  <>
                    {r.image_url && <img src={r.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-neutral-900 truncate">{r.title}</p>
                      <div className="flex items-center gap-3 text-xs text-neutral-400 mt-0.5">
                        <span className="inline-flex items-center gap-0.5"><Clock className="w-3 h-3" />{r.prep_time_min + r.cook_time_min}m</span>
                        <span className="inline-flex items-center gap-0.5"><Users className="w-3 h-3" />{r.servings}</span>
                      </div>
                    </div>
                  </>
                ) : null;
              })()}
            </div>
          )}
          <button
            onClick={handleAdd}
            disabled={!addRecipeId}
            className="w-full py-2.5 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all disabled:opacity-50"
          >
            Add to Plan
          </button>
        </div>
      </Modal>
    </div>
  );
}

function getWeekStart(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  d.setDate(d.getDate() - day);
  d.setHours(0, 0, 0, 0);
  return d;
}

function SummaryStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="text-center p-3 rounded-xl bg-neutral-50">
      <div className="text-2xl font-bold text-neutral-900 font-display">{value}</div>
      <div className="text-xs text-neutral-400 mt-0.5">{label}</div>
    </div>
  );
}
