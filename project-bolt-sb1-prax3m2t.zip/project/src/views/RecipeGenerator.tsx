import { useState, useEffect } from 'react';
import { supabase, type Recipe, type PantryItem, CUISINES } from '../lib/supabase';
import { generateRecipe } from '../lib/recipeGenerator';
import { showToast } from '../components/Toast';
import { Sparkles, Wand2, RefreshCw, Plus, Check, Loader2 } from 'lucide-react';

type RecipeGeneratorProps = {
  onOpenRecipe: (recipe: Recipe) => void;
};

const DIETARY_PREFS = ['None', 'Vegetarian', 'Vegan', 'Gluten-Free', 'High-Protein', 'Low-Carb'];

export function RecipeGenerator({ onOpenRecipe }: RecipeGeneratorProps) {
  const [pantryItems, setPantryItems] = useState<PantryItem[]>([]);
  const [selectedIngredients, setSelectedIngredients] = useState<Set<string>>(new Set());
  const [cuisine, setCuisine] = useState('');
  const [dietaryPref, setDietaryPref] = useState('None');
  const [maxTime, setMaxTime] = useState(60);
  const [generating, setGenerating] = useState(false);
  const [generatedRecipes, setGeneratedRecipes] = useState<Recipe[]>([]);
  const [hasGenerated, setHasGenerated] = useState(false);

  useEffect(() => { loadPantry(); }, []);

  const loadPantry = async () => {
    const { data } = await supabase.from('pantry_items').select('*').order('name');
    if (data) {
      setPantryItems(data as PantryItem[]);
      setSelectedIngredients(new Set(data.map(d => d.name)));
    }
  };

  const toggleIngredient = (name: string) => {
    setSelectedIngredients(prev => {
      const next = new Set(prev);
      next.has(name) ? next.delete(name) : next.add(name);
      return next;
    });
  };

  const selectAll = () => setSelectedIngredients(new Set(pantryItems.map(p => p.name)));
  const clearAll = () => setSelectedIngredients(new Set());

  const handleGenerate = async () => {
    if (selectedIngredients.size === 0) {
      showToast('Select at least one ingredient', 'error');
      return;
    }
    setGenerating(true);
    setHasGenerated(true);

    await new Promise(r => setTimeout(r, 1200));

    const pantryNames = Array.from(selectedIngredients);
    const recipes: Recipe[] = [];
    for (let i = 0; i < 3; i++) {
      const recipe = generateRecipe({
        pantryNames,
        cuisine: cuisine || undefined,
        dietaryPreference: dietaryPref !== 'None' ? dietaryPref : undefined,
        maxTime,
      }, i * 7);
      recipes.push(recipe);
    }
    setGeneratedRecipes(recipes);
    setGenerating(false);
    showToast('3 AI recipes generated');
  };

  const handleRegenerate = () => {
    setGeneratedRecipes([]);
    handleGenerate();
  };

  const handleSave = async (recipe: Recipe) => {
    const { id, ...rest } = recipe;
    const { error } = await supabase.from('recipes').insert({
      ...rest,
      source: 'ai',
    });
    if (error) {
      showToast('Failed to save recipe', 'error');
      return;
    }
    showToast('Recipe saved to your collection');
  };

  const handleAddToGrocery = async (recipe: Recipe) => {
    const items = recipe.ingredients.map(ing => ({
      name: ing.name,
      quantity: ing.amount,
      unit: ing.unit,
      category: 'Other',
      checked: false,
    }));
    const { error } = await supabase.from('grocery_items').insert(items);
    if (error) {
      showToast('Failed to add to grocery list', 'error');
      return;
    }
    showToast('Ingredients added to grocery list');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl lg:text-3xl font-bold text-neutral-900 flex items-center gap-2">
          <Wand2 className="w-6 h-6 text-primary-600" />
          AI Recipe Generator
        </h1>
        <p className="text-neutral-500 mt-1">Select your ingredients and let AI craft personalized recipes.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left panel — controls */}
        <div className="lg:col-span-1 space-y-5">
          {/* Ingredients selection */}
          <div className="bg-white rounded-2xl border border-neutral-200 p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-neutral-900 text-sm">Your Ingredients</h3>
              <div className="flex gap-2">
                <button onClick={selectAll} className="text-xs text-primary-600 hover:text-primary-700 font-medium">All</button>
                <button onClick={clearAll} className="text-xs text-neutral-400 hover:text-neutral-600 font-medium">Clear</button>
              </div>
            </div>
            {pantryItems.length === 0 ? (
              <p className="text-sm text-neutral-400 py-4 text-center">
                No pantry items yet. Scan ingredients first.
              </p>
            ) : (
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
                {pantryItems.map(item => {
                  const selected = selectedIngredients.has(item.name);
                  return (
                    <button
                      key={item.id}
                      onClick={() => toggleIngredient(item.name)}
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                        selected
                          ? 'bg-gradient-warm text-white shadow-soft'
                          : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                      }`}
                    >
                      {selected && <Check className="w-3 h-3" />}
                      {item.name}
                    </button>
                  );
                })}
              </div>
            )}
            <p className="mt-3 text-xs text-neutral-400">{selectedIngredients.size} selected</p>
          </div>

          {/* Preferences */}
          <div className="bg-white rounded-2xl border border-neutral-200 p-5 space-y-4">
            <h3 className="font-semibold text-neutral-900 text-sm">Preferences</h3>

            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1.5">Cuisine</label>
              <select
                value={cuisine}
                onChange={e => setCuisine(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
              >
                <option value="">Any cuisine</option>
                {CUISINES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1.5">Dietary Preference</label>
              <div className="flex flex-wrap gap-1.5">
                {DIETARY_PREFS.map(pref => (
                  <button
                    key={pref}
                    onClick={() => setDietaryPref(pref)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      dietaryPref === pref
                        ? 'bg-neutral-900 text-white'
                        : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                  >
                    {pref}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1.5">
                Max Cook Time: <span className="text-primary-600 font-semibold">{maxTime} min</span>
              </label>
              <input
                type="range"
                min="15"
                max="90"
                step="5"
                value={maxTime}
                onChange={e => setMaxTime(Number(e.target.value))}
                className="w-full accent-primary-500"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={generating || selectedIngredients.size === 0}
              className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate Recipes
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right panel — results */}
        <div className="lg:col-span-2">
          {!hasGenerated ? (
            <div className="bg-white rounded-2xl border border-neutral-200 h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary-100 to-accent-100 flex items-center justify-center mb-4">
                <Wand2 className="w-9 h-9 text-primary-600" />
              </div>
              <h3 className="font-display text-xl font-bold text-neutral-900">Ready to cook something amazing?</h3>
              <p className="text-sm text-neutral-500 mt-2 max-w-sm">
                Select your ingredients and preferences, then click Generate to get personalized AI recipes.
              </p>
            </div>
          ) : generating ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-white rounded-2xl border border-neutral-200 overflow-hidden">
                  <div className="h-40 skeleton" />
                  <div className="p-4 space-y-2">
                    <div className="h-5 w-2/3 rounded skeleton" />
                    <div className="h-4 w-full rounded skeleton" />
                    <div className="h-4 w-1/2 rounded skeleton" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-neutral-900">
                  AI-Generated Recipes <span className="text-neutral-400 font-normal">({generatedRecipes.length})</span>
                </h2>
                <button
                  onClick={handleRegenerate}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-white border border-neutral-200 text-neutral-700 hover:border-primary-300 hover:text-primary-700 transition-all"
                >
                  <RefreshCw className="w-4 h-4" />
                  Regenerate
                </button>
              </div>
              {generatedRecipes.map(recipe => (
                <div key={recipe.id} className="bg-white rounded-2xl border border-neutral-200 overflow-hidden hover:shadow-medium transition-all">
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-48 h-40 sm:h-auto shrink-0 overflow-hidden cursor-pointer" onClick={() => onOpenRecipe(recipe)}>
                      <img src={recipe.image_url || ''} alt={recipe.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onOpenRecipe(recipe)}>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-gradient-warm text-white">
                              <Sparkles className="w-2.5 h-2.5" /> AI
                            </span>
                            <span className="text-xs text-neutral-400">{recipe.cuisine} · {recipe.difficulty}</span>
                          </div>
                          <h3 className="font-display text-lg font-bold text-neutral-900 hover:text-primary-600 transition-colors">{recipe.title}</h3>
                          <p className="text-sm text-neutral-500 mt-1 line-clamp-2">{recipe.description}</p>
                          <div className="mt-2 flex flex-wrap gap-1.5">
                            {recipe.tags.slice(0, 4).map(tag => (
                              <span key={tag} className="px-2 py-0.5 rounded text-xs bg-neutral-100 text-neutral-500">#{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <button
                          onClick={() => onOpenRecipe(recipe)}
                          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-colors"
                        >
                          View Recipe
                        </button>
                        <button
                          onClick={() => handleSave(recipe)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium bg-primary-50 text-primary-700 hover:bg-primary-100 transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          Save
                        </button>
                        <button
                          onClick={() => handleAddToGrocery(recipe)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium bg-secondary-50 text-secondary-700 hover:bg-secondary-100 transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" />
                          To Grocery
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
