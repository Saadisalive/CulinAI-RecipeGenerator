import { useState, useEffect } from 'react';
import { supabase, type Recipe } from '../lib/supabase';
import { RecipeCard } from '../components/RecipeCard';
import { Sparkles, ScanLine, Calendar, ShoppingCart, ArrowRight, TrendingUp, Clock, Flame } from 'lucide-react';

type DashboardProps = {
  onOpenRecipe: (recipe: Recipe) => void;
  onNavigate: (view: any) => void;
};

export function Dashboard({ onOpenRecipe, onNavigate }: DashboardProps) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ recipes: 0, pantry: 0, planned: 0, grocery: 0 });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [recipeRes, pantryRes, mealRes, groceryRes] = await Promise.all([
      supabase.from('recipes').select('*').order('created_at', { ascending: false }).limit(8),
      supabase.from('pantry_items').select('id'),
      supabase.from('meal_plans').select('id').gte('plan_date', new Date().toISOString().split('T')[0]),
      supabase.from('grocery_items').select('id, checked').eq('checked', false),
    ]);

    if (recipeRes.data) setRecipes(recipeRes.data as Recipe[]);
    setStats({
      recipes: recipeRes.data?.length || 0,
      pantry: pantryRes.data?.length || 0,
      planned: mealRes.data?.length || 0,
      grocery: groceryRes.data?.length || 0,
    });
    setLoading(false);
  };

  const featured = recipes[0];
  const rest = recipes.slice(1);

  const quickActions = [
    { label: 'Scan Ingredients', desc: 'Add what you have', icon: ScanLine, view: 'scan', gradient: 'from-secondary-500 to-secondary-600' },
    { label: 'AI Recipe Generator', desc: 'Create from pantry', icon: Sparkles, view: 'generate', gradient: 'from-primary-500 to-accent-500' },
    { label: 'Meal Planner', desc: 'Plan your week', icon: Calendar, view: 'planner', gradient: 'from-accent-500 to-warning-500' },
    { label: 'Grocery List', desc: 'Shop smart', icon: ShoppingCart, view: 'grocery', gradient: 'from-secondary-600 to-primary-600' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-dark text-white">
        <div className="absolute inset-0 opacity-30">
          <img
            src="https://images.pexels.com/photos/302468/pexels-photo-302468.jpeg?auto=compress&cs=tinysrgb&w=1200"
            alt="Cooking background"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative px-6 py-10 lg:px-12 lg:py-16">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm text-sm mb-4">
              <Sparkles className="w-4 h-4 text-accent-400" />
              <span>AI-Powered Cooking Companion</span>
            </div>
            <h1 className="font-display text-3xl lg:text-5xl font-bold leading-tight text-balance">
              Cook smarter with recipes tailored to what you have
            </h1>
            <p className="mt-4 text-lg text-neutral-300 max-w-xl">
              Scan your ingredients, generate AI recipes, plan your meals, and master cooking techniques — all in one place.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                onClick={() => onNavigate('generate')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-warm font-semibold text-white hover:shadow-glow transition-all"
              >
                <Sparkles className="w-4 h-4" />
                Generate Recipe
              </button>
              <button
                onClick={() => onNavigate('scan')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 font-semibold text-white hover:bg-white/20 transition-all"
              >
                <ScanLine className="w-4 h-4" />
                Scan Ingredients
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Recipes" value={stats.recipes} icon={Flame} color="text-primary-600" bg="bg-primary-50" />
        <StatCard label="Pantry Items" value={stats.pantry} icon={ScanLine} color="text-secondary-600" bg="bg-secondary-50" />
        <StatCard label="Meals Planned" value={stats.planned} icon={Calendar} color="text-accent-600" bg="bg-accent-50" />
        <StatCard label="Grocery Items" value={stats.grocery} icon={ShoppingCart} color="text-warning-600" bg="bg-warning-50" />
      </section>

      {/* Quick actions */}
      <section>
        <h2 className="font-display text-xl font-bold text-neutral-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map(a => {
            const Icon = a.icon;
            return (
              <button
                key={a.label}
                onClick={() => onNavigate(a.view)}
                className="group relative overflow-hidden rounded-2xl p-5 text-left bg-white border border-neutral-200 hover:shadow-medium transition-all hover:-translate-y-0.5"
              >
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${a.gradient} flex items-center justify-center mb-3`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold text-neutral-900 text-sm">{a.label}</h3>
                <p className="text-xs text-neutral-400 mt-0.5">{a.desc}</p>
                <ArrowRight className="absolute top-5 right-5 w-4 h-4 text-neutral-300 group-hover:text-primary-500 group-hover:translate-x-1 transition-all" />
              </button>
            );
          })}
        </div>
      </section>

      {/* Featured recipe */}
      {featured && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-xl font-bold text-neutral-900 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary-600" />
              Featured Recipe
            </h2>
          </div>
          <div
            onClick={() => onOpenRecipe(featured)}
            className="group cursor-pointer relative overflow-hidden rounded-2xl shadow-medium hover:shadow-large transition-all"
          >
            <div className="relative h-64 lg:h-80 overflow-hidden">
              <img src={featured.image_url || ''} alt={featured.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-white/20 backdrop-blur-sm text-white">{featured.cuisine}</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-white/20 backdrop-blur-sm text-white">{featured.difficulty}</span>
                </div>
                <h3 className="font-display text-2xl lg:text-3xl font-bold text-white mb-2">{featured.title}</h3>
                <p className="text-neutral-200 text-sm lg:text-base max-w-xl line-clamp-2">{featured.description}</p>
                <div className="mt-3 flex items-center gap-4 text-sm text-neutral-300">
                  <span className="inline-flex items-center gap-1"><Clock className="w-4 h-4" />{featured.prep_time_min + featured.cook_time_min} min</span>
                  <span className="inline-flex items-center gap-1"><Flame className="w-4 h-4" />{featured.nutrition?.calories || 0} cal</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Recipe grid */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold text-neutral-900">Discover Recipes</h2>
        </div>
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-soft">
                <div className="h-52 skeleton" />
                <div className="p-4 space-y-2">
                  <div className="h-4 w-3/4 rounded skeleton" />
                  <div className="h-3 w-full rounded skeleton" />
                  <div className="h-3 w-1/2 rounded skeleton" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {rest.map(r => (
              <RecipeCard key={r.id} recipe={r} onClick={() => onOpenRecipe(r)} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color, bg }: { label: string; value: number; icon: any; color: string; bg: string }) {
  return (
    <div className="bg-white rounded-2xl p-5 border border-neutral-200 hover:shadow-soft transition-all">
      <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center mb-3`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <div className="text-2xl font-bold text-neutral-900 font-display">{value}</div>
      <div className="text-xs text-neutral-400 mt-0.5">{label}</div>
    </div>
  );
}
