import { useState, useEffect } from 'react';
import { supabase, type PantryItem, CATEGORIES } from '../lib/supabase';
import { classifyIngredient } from '../lib/recipeGenerator';
import { showToast } from '../components/Toast';
import { ScanLine, Plus, Search, Trash2, Sparkles, X, Camera, Check } from 'lucide-react';

type ScanIngredientsProps = {
  onNavigate: (view: any) => void;
};

const CATEGORY_COLORS: Record<string, string> = {
  Produce: 'bg-success-100 text-success-700 border-success-200',
  Dairy: 'bg-blue-100 text-blue-700 border-blue-200',
  Meat: 'bg-error-100 text-error-700 border-error-200',
  Pantry: 'bg-accent-100 text-accent-700 border-accent-200',
  Frozen: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  Spices: 'bg-warning-100 text-warning-700 border-warning-200',
  Bakery: 'bg-amber-100 text-amber-700 border-amber-200',
  Beverages: 'bg-purple-100 text-purple-700 border-purple-200',
  Other: 'bg-neutral-100 text-neutral-700 border-neutral-200',
};

export function ScanIngredients({ onNavigate }: ScanIngredientsProps) {
  const [items, setItems] = useState<PantryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [showAdd, setShowAdd] = useState(false);
  const [scanMode, setScanMode] = useState(false);
  const [scanInput, setScanInput] = useState('');
  const [newItem, setNewItem] = useState({ name: '', quantity: '', unit: '', category: 'Other' });

  useEffect(() => { loadItems(); }, []);

  const loadItems = async () => {
    setLoading(true);
    const { data } = await supabase.from('pantry_items').select('*').order('category').order('name');
    if (data) setItems(data as PantryItem[]);
    setLoading(false);
  };

  const handleAdd = async () => {
    if (!newItem.name.trim()) {
      showToast('Please enter an ingredient name', 'error');
      return;
    }
    const { error } = await supabase.from('pantry_items').insert({
      name: newItem.name.trim(),
      quantity: newItem.quantity || null,
      unit: newItem.unit || null,
      category: newItem.category,
    });
    if (error) {
      showToast('Failed to add ingredient', 'error');
      return;
    }
    showToast('Ingredient added to pantry');
    setNewItem({ name: '', quantity: '', unit: '', category: 'Other' });
    loadItems();
  };

  const handleScan = async () => {
    if (!scanInput.trim()) return;
    const lines = scanInput.split(/[,\n]/).map(l => l.trim()).filter(Boolean);
    const rows = lines.map(line => {
      const { category, name } = classifyIngredient(line);
      return { name, category, quantity: null, unit: null };
    });
    if (rows.length === 0) return;
    const { error } = await supabase.from('pantry_items').insert(rows);
    if (error) {
      showToast('Failed to scan ingredients', 'error');
      return;
    }
    showToast(`${rows.length} ingredients scanned`);
    setScanInput('');
    setScanMode(false);
    loadItems();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('pantry_items').delete().eq('id', id);
    setItems(prev => prev.filter(i => i.id !== id));
    showToast('Ingredient removed');
  };

  const filtered = items.filter(i => {
    const matchesSearch = i.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = activeCategory === 'All' || i.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const grouped = filtered.reduce((acc, item) => {
    (acc[item.category] = acc[item.category] || []).push(item);
    return acc;
  }, {} as Record<string, PantryItem[]>);

  const generateFromPantry = () => {
    if (items.length === 0) {
      showToast('Add some ingredients first', 'error');
      return;
    }
    onNavigate('generate');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-neutral-900">Scan Ingredients</h1>
          <p className="text-neutral-500 mt-1">Add what's in your kitchen and let AI suggest recipes.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setScanMode(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white border border-neutral-200 text-neutral-700 font-medium hover:border-primary-300 hover:text-primary-700 transition-all"
          >
            <Camera className="w-4 h-4" />
            Scan
          </button>
          <button
            onClick={() => setShowAdd(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Ingredient
          </button>
        </div>
      </div>

      {/* AI suggestion banner */}
      {items.length > 0 && (
        <div className="flex items-center justify-between gap-4 p-4 lg:p-5 rounded-2xl bg-gradient-to-r from-primary-50 to-accent-50 border border-primary-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-warm flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold text-neutral-900">Ready to cook with what you have?</p>
              <p className="text-sm text-neutral-600">You have {items.length} ingredients. Generate AI recipes now.</p>
            </div>
          </div>
          <button
            onClick={generateFromPantry}
            className="shrink-0 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-warm text-white text-sm font-semibold hover:shadow-glow transition-all"
          >
            <Sparkles className="w-4 h-4" />
            Generate
          </button>
        </div>
      )}

      {/* Search + filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search your pantry..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 focus:border-primary-300"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {['All', ...CATEGORIES].map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? 'bg-neutral-900 text-white'
                  : 'bg-white border border-neutral-200 text-neutral-600 hover:border-neutral-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Items */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-20 rounded-xl skeleton" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-2xl bg-neutral-100 flex items-center justify-center mx-auto mb-4">
            <ScanLine className="w-7 h-7 text-neutral-400" />
          </div>
          <h3 className="font-display text-lg font-semibold text-neutral-700">
            {items.length === 0 ? 'Your pantry is empty' : 'No ingredients found'}
          </h3>
          <p className="text-sm text-neutral-400 mt-1 mb-4">
            {items.length === 0 ? 'Start by adding or scanning your ingredients.' : 'Try a different search or filter.'}
          </p>
          {items.length === 0 && (
            <button
              onClick={() => setShowAdd(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Your First Ingredient
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(grouped).map(([category, catItems]) => (
            <div key={category}>
              <h3 className="text-sm font-semibold text-neutral-500 uppercase tracking-wide mb-3">
                {category} <span className="text-neutral-300">({catItems.length})</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {catItems.map(item => (
                  <div
                    key={item.id}
                    className="group flex items-center justify-between gap-3 p-3.5 rounded-xl bg-white border border-neutral-200 hover:border-neutral-300 hover:shadow-soft transition-all"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-10 h-10 rounded-lg border flex items-center justify-center shrink-0 ${CATEGORY_COLORS[item.category] || CATEGORY_COLORS.Other}`}>
                        <span className="text-xs font-bold">{item.name.charAt(0)}</span>
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium text-neutral-900 truncate">{item.name}</p>
                        <p className="text-xs text-neutral-400">
                          {item.quantity && item.unit ? `${item.quantity} ${item.unit}` : item.quantity || item.category}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 rounded-lg text-neutral-300 hover:text-error-600 hover:bg-error-50 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/50 backdrop-blur-sm animate-fade-in" onClick={(e) => e.target === e.currentTarget && setShowAdd(false)}>
          <div className="w-full max-w-md bg-white rounded-2xl shadow-large animate-scale-in p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-lg font-bold text-neutral-900">Add Ingredient</h2>
              <button onClick={() => setShowAdd(false)} className="p-2 rounded-lg hover:bg-neutral-100"><X className="w-4 h-4 text-neutral-500" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1.5">Name</label>
                <input
                  value={newItem.name}
                  onChange={e => {
                    const classified = classifyIngredient(e.target.value);
                    setNewItem(prev => ({ ...prev, name: e.target.value, category: classified.category }));
                  }}
                  placeholder="e.g., Chicken breast"
                  className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  autoFocus
                  onKeyDown={e => e.key === 'Enter' && handleAdd()}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5">Quantity</label>
                  <input
                    value={newItem.quantity}
                    onChange={e => setNewItem(prev => ({ ...prev, quantity: e.target.value }))}
                    placeholder="2"
                    className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5">Unit</label>
                  <input
                    value={newItem.unit}
                    onChange={e => setNewItem(prev => ({ ...prev, unit: e.target.value }))}
                    placeholder="cups"
                    className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1.5">Category</label>
                <select
                  value={newItem.category}
                  onChange={e => setNewItem(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <button
                onClick={handleAdd}
                className="w-full py-2.5 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all"
              >
                Add to Pantry
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Scan modal */}
      {scanMode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/50 backdrop-blur-sm animate-fade-in" onClick={(e) => e.target === e.currentTarget && setScanMode(false)}>
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-large animate-scale-in p-6">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-primary-600" />
                <h2 className="font-display text-lg font-bold text-neutral-900">Scan Ingredients</h2>
              </div>
              <button onClick={() => setScanMode(false)} className="p-2 rounded-lg hover:bg-neutral-100"><X className="w-4 h-4 text-neutral-500" /></button>
            </div>
            <div className="space-y-4">
              <div className="rounded-xl border-2 border-dashed border-neutral-200 p-8 text-center bg-neutral-50">
                <Camera className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
                <p className="text-sm text-neutral-500">Camera scanning simulated — type or paste your ingredient list below.</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1.5">Ingredient List</label>
                <textarea
                  value={scanInput}
                  onChange={e => setScanInput(e.target.value)}
                  placeholder="e.g.,&#10;2 chicken breasts&#10;spinach&#10;garlic&#10;olive oil"
                  rows={5}
                  className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 resize-none"
                  autoFocus
                />
                <p className="text-xs text-neutral-400 mt-1">Separate items with commas or new lines. Categories auto-detected.</p>
              </div>
              <button
                onClick={handleScan}
                disabled={!scanInput.trim()}
                className="w-full py-2.5 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all disabled:opacity-50"
              >
                <span className="inline-flex items-center gap-2 justify-center">
                  <Check className="w-4 h-4" />
                  Scan & Add All
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
