import { useState, useEffect } from 'react';
import { supabase, type GroceryItem, CATEGORIES } from '../lib/supabase';
import { showToast } from '../components/Toast';
import {
  ShoppingCart, Plus, Trash2, Check, X, Search,
} from 'lucide-react';

const CATEGORY_ICONS: Record<string, string> = {
  Produce: '🥬', Dairy: '🥛', Meat: '🥩', Pantry: '🥫',
  Frozen: '🧊', Spices: '🧂', Bakery: '🍞', Beverages: '🥤', Other: '📦',
};

export function GroceryList() {
  const [items, setItems] = useState<GroceryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newItem, setNewItem] = useState({ name: '', quantity: '', unit: '', category: 'Other' });
  const [filter, setFilter] = useState<'all' | 'pending' | 'checked'>('all');

  useEffect(() => { loadItems(); }, []);

  const loadItems = async () => {
    setLoading(true);
    const { data } = await supabase.from('grocery_items').select('*').order('category').order('name');
    if (data) setItems(data as GroceryItem[]);
    setLoading(false);
  };

  const handleAdd = async () => {
    if (!newItem.name.trim()) {
      showToast('Enter an item name', 'error');
      return;
    }
    const { error } = await supabase.from('grocery_items').insert({
      name: newItem.name.trim(),
      quantity: newItem.quantity || null,
      unit: newItem.unit || null,
      category: newItem.category,
      checked: false,
    });
    if (error) {
      showToast('Failed to add item', 'error');
      return;
    }
    showToast('Item added to grocery list');
    setNewItem({ name: '', quantity: '', unit: '', category: 'Other' });
    loadItems();
  };

  const handleToggle = async (item: GroceryItem) => {
    await supabase.from('grocery_items').update({ checked: !item.checked }).eq('id', item.id);
    setItems(prev => prev.map(i => i.id === item.id ? { ...i, checked: !i.checked } : i));
  };

  const handleDelete = async (id: string) => {
    await supabase.from('grocery_items').delete().eq('id', id);
    setItems(prev => prev.filter(i => i.id !== id));
  };

  const handleClearChecked = async () => {
    const checked = items.filter(i => i.checked);
    if (checked.length === 0) {
      showToast('No checked items to clear', 'info');
      return;
    }
    await supabase.from('grocery_items').delete().in('id', checked.map(i => i.id));
    setItems(prev => prev.filter(i => !i.checked));
    showToast(`Cleared ${checked.length} items`);
  };

  const filtered = items.filter(i => {
    const matchesSearch = i.name.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' || (filter === 'pending' && !i.checked) || (filter === 'checked' && i.checked);
    return matchesSearch && matchesFilter;
  });

  const grouped = filtered.reduce((acc, item) => {
    (acc[item.category] = acc[item.category] || []).push(item);
    return acc;
  }, {} as Record<string, GroceryItem[]>);

  const pendingCount = items.filter(i => !i.checked).length;
  const checkedCount = items.filter(i => i.checked).length;
  const progress = items.length > 0 ? (checkedCount / items.length) * 100 : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-neutral-900 flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-primary-600" />
            Grocery List
          </h1>
          <p className="text-neutral-500 mt-1">{pendingCount} items to buy · {checkedCount} in cart</p>
        </div>
        <div className="flex gap-2">
          {checkedCount > 0 && (
            <button
              onClick={handleClearChecked}
              className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white border border-neutral-200 text-neutral-700 font-medium hover:border-error-300 hover:text-error-600 transition-all text-sm"
            >
              <Trash2 className="w-4 h-4" />
              Clear Checked
            </button>
          )}
          <button
            onClick={() => setShowAdd(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Item
          </button>
        </div>
      </div>

      {/* Progress bar */}
      {items.length > 0 && (
        <div className="bg-white rounded-2xl border border-neutral-200 p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-neutral-700">Shopping Progress</span>
            <span className="text-sm font-bold text-primary-600">{Math.round(progress)}%</span>
          </div>
          <div className="h-3 rounded-full bg-neutral-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-fresh transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-neutral-400">
            <span>{checkedCount} of {items.length} collected</span>
            {progress === 100 && <span className="text-success-600 font-medium flex items-center gap-1"><Check className="w-3 h-3" /> All done!</span>}
          </div>
        </div>
      )}

      {/* Search + filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search items..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-neutral-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'pending', 'checked'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
                filter === f ? 'bg-neutral-900 text-white' : 'bg-white border border-neutral-200 text-neutral-600'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Items */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-xl skeleton" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-2xl bg-neutral-100 flex items-center justify-center mx-auto mb-4">
            <ShoppingCart className="w-7 h-7 text-neutral-400" />
          </div>
          <h3 className="font-display text-lg font-semibold text-neutral-700">
            {items.length === 0 ? 'Your grocery list is empty' : 'No items found'}
          </h3>
          <p className="text-sm text-neutral-400 mt-1 mb-4">
            {items.length === 0 ? 'Add items manually or from a recipe.' : 'Try a different search or filter.'}
          </p>
          {items.length === 0 && (
            <button
              onClick={() => setShowAdd(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-warm text-white font-medium hover:shadow-glow transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Your First Item
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-5">
          {Object.entries(grouped).map(([category, catItems]) => (
            <div key={category}>
              <h3 className="text-sm font-semibold text-neutral-500 uppercase tracking-wide mb-2 flex items-center gap-2">
                <span>{CATEGORY_ICONS[category] || '📦'}</span>
                {category} <span className="text-neutral-300">({catItems.length})</span>
              </h3>
              <div className="space-y-1.5">
                {catItems.map(item => (
                  <div
                    key={item.id}
                    className={`group flex items-center gap-3 p-3 rounded-xl border transition-all ${
                      item.checked
                        ? 'bg-neutral-50 border-neutral-200'
                        : 'bg-white border-neutral-200 hover:border-neutral-300'
                    }`}
                  >
                    <button
                      onClick={() => handleToggle(item)}
                      className={`shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center transition-all ${
                        item.checked
                          ? 'bg-success-500 border-success-500 text-white'
                          : 'border-neutral-300 hover:border-success-400'
                      }`}
                    >
                      {item.checked && <Check className="w-4 h-4" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium truncate ${item.checked ? 'text-neutral-400 line-through' : 'text-neutral-900'}`}>
                        {item.name}
                      </p>
                      {item.quantity && (
                        <p className={`text-xs ${item.checked ? 'text-neutral-300' : 'text-neutral-400'}`}>
                          {item.quantity} {item.unit}
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 rounded-lg text-neutral-300 hover:text-error-600 hover:bg-error-50 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/50 backdrop-blur-sm animate-fade-in" onClick={(e) => e.target === e.currentTarget && setShowAdd(false)}>
          <div className="w-full max-w-md bg-white rounded-2xl shadow-large animate-scale-in p-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-display text-lg font-bold text-neutral-900">Add Grocery Item</h2>
              <button onClick={() => setShowAdd(false)} className="p-2 rounded-lg hover:bg-neutral-100"><X className="w-4 h-4 text-neutral-500" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1.5">Name</label>
                <input
                  value={newItem.name}
                  onChange={e => setNewItem(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., Olive oil"
                  className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  autoFocus
                  onKeyDown={e => e.key === 'Enter' && handleAdd()}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5">Quantity</label>
                  <input
                    value={newItem.quantity}
                    onChange={e => setNewItem(prev => ({ ...prev, quantity: e.target.value }))}
                    placeholder="1"
                    className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5">Unit</label>
                  <input
                    value={newItem.unit}
                    onChange={e => setNewItem(prev => ({ ...prev, unit: e.target.value }))}
                    placeholder="bottle"
                    className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1.5">Category</label>
                <select
                  value={newItem.category}
                  onChange={e => setNewItem(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
                >
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <button
                onClick={handleAdd}
                className="w-full py-2.5 rounded-xl bg-gradient-warm text-white font-semibold hover:shadow-glow transition-all"
              >
                Add to List
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
