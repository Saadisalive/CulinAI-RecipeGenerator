import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Ingredient = {
  name: string;
  amount: string;
  unit: string;
};

export type Instruction = {
  step: number;
  text: string;
  timer_min?: number;
};

export type Nutrition = {
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  fiber_g: number;
  sodium_mg: number;
  sugar_g: number;
};

export type Recipe = {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  prep_time_min: number;
  cook_time_min: number;
  servings: number;
  difficulty: string;
  cuisine: string;
  meal_type: string;
  ingredients: Ingredient[];
  instructions: Instruction[];
  nutrition: Nutrition;
  video_url: string | null;
  tags: string[];
  source: string;
  created_at: string;
};

export type PantryItem = {
  id: string;
  name: string;
  quantity: string | null;
  unit: string | null;
  category: string;
  image_url: string | null;
  notes: string | null;
  created_at: string;
};

export type MealPlan = {
  id: string;
  plan_date: string;
  meal_type: string;
  recipe_id: string | null;
  servings: number;
  created_at: string;
};

export type GroceryItem = {
  id: string;
  name: string;
  quantity: string | null;
  unit: string | null;
  category: string;
  checked: boolean;
  recipe_id: string | null;
  created_at: string;
};

export const CATEGORIES = [
  'Produce', 'Dairy', 'Meat', 'Pantry', 'Frozen', 'Spices', 'Bakery', 'Beverages', 'Other',
] as const;

export const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snack'] as const;

export const DIFFICULTIES = ['Easy', 'Medium', 'Hard'] as const;

export const CUISINES = [
  'Italian', 'American', 'Thai', 'Japanese', 'Greek', 'French', 'Mexican', 'Indian', 'Chinese', 'Korean', 'Spanish', 'Other',
] as const;
