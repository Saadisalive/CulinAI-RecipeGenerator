import type { Ingredient, Instruction, Nutrition, Recipe } from './supabase';

// A local "AI" recipe generator that constructs recipes from available ingredients.
// Uses combinatorial templates and flavor pairing rules to produce varied results.

const PROTEINS = ['chicken', 'beef', 'tofu', 'shrimp', 'salmon', 'chickpeas', 'pork', 'mushrooms'];
const CARBS = ['rice', 'pasta', 'quinoa', 'bread', 'potatoes', 'noodles', 'couscous'];
const VEGETABLES = ['bell pepper', 'broccoli', 'spinach', 'onion', 'garlic', 'tomato', 'carrot', 'zucchini', 'kale', 'asparagus'];

const CUISINE_PROFILES: Record<string, { herbs: string[]; spices: string[]; base: string; style: string }> = {
  Italian: { herbs: ['basil', 'oregano', 'rosemary'], spices: ['paprika'], base: 'olive oil', style: 'Mediterranean' },
  Thai: { herbs: ['cilantro', 'mint'], spices: ['turmeric', 'chili powder'], base: 'coconut milk', style: 'Southeast Asian' },
  Mexican: { herbs: ['cilantro', 'oregano'], spices: ['cumin', 'chili powder'], base: 'lime juice', style: 'Latin American' },
  Indian: { herbs: ['cilantro'], spices: ['turmeric', 'cumin', 'coriander'], base: 'ghee', style: 'South Asian' },
  Japanese: { herbs: ['mint'], spices: ['paprika'], base: 'soy sauce', style: 'East Asian' },
  American: { herbs: ['parsley', 'thyme'], spices: ['paprika'], base: 'butter', style: 'American' },
  French: { herbs: ['thyme', 'rosemary', 'chives'], spices: ['paprika'], base: 'butter', style: 'French' },
  Greek: { herbs: ['oregano', 'mint'], spices: ['paprika'], base: 'olive oil', style: 'Mediterranean' },
};

const DISH_TEMPLATES = [
  { name: 'Stir-Fry', method: 'stir-fry', cookTime: 15, steps: ['prep', 'heat_oil', 'cook_protein', 'add_veg', 'sauce', 'serve'] },
  { name: 'Bowl', method: 'bowl', cookTime: 20, steps: ['cook_grain', 'prep_veg', 'cook_protein', 'assemble', 'dress', 'serve'] },
  { name: 'Pasta', method: 'pasta', cookTime: 25, steps: ['boil_water', 'cook_pasta', 'sauce', 'cook_protein', 'combine', 'serve'] },
  { name: 'Curry', method: 'curry', cookTime: 30, steps: ['aromatics', 'spices', 'protein', 'sauce', 'simmer', 'serve'] },
  { name: 'Skillet', method: 'skillet', cookTime: 20, steps: ['heat_oil', 'sear_protein', 'add_veg', 'deglaze', 'reduce', 'serve'] },
  { name: 'Sheet Pan', method: 'sheet_pan', cookTime: 35, steps: ['prep', 'season', 'arrange', 'roast', 'finish', 'serve'] },
];

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

function pickMany<T>(arr: T[], count: number, seed: number): T[] {
  const result: T[] = [];
  for (let i = 0; i < count && i < arr.length; i++) {
    result.push(arr[(seed + i * 3) % arr.length]);
  }
  return result;
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

const IMAGE_POOL = [
  'https://images.pexels.com/photos/675951/pexels-photo-675951.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/376464/pexels-photo-376464.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/8500/food-dinner-pasta-spaghetti.jpg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/674574/pexels-photo-674574.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=800',
];

const VIDEO_POOL = [
  'https://www.youtube.com/embed/D-n6rD3I8E8',
  'https://www.youtube.com/embed/8VBnaFhOEn8',
  'https://www.youtube.com/embed/L_nB6vGyqdk',
  'https://www.youtube.com/embed/JHZ_uQZcW-k',
];

export type GenerateOptions = {
  pantryNames: string[];
  cuisine?: string;
  dietaryPreference?: string;
  maxTime?: number;
};

export function generateRecipe(opts: GenerateOptions, salt = 0): Recipe {
  const seedStr = opts.pantryNames.join(',') + (opts.cuisine || '') + (opts.dietaryPreference || '') + salt;
  const seed = hashString(seedStr);

  const cuisine = opts.cuisine || pick(Object.keys(CUISINE_PROFILES), seed);
  const profile = CUISINE_PROFILES[cuisine] || CUISINE_PROFILES.Italian;
  const template = pick(DISH_TEMPLATES, seed >> 2);

  // Determine protein from pantry or fallback
  const pantryLower = opts.pantryNames.map(n => n.toLowerCase());
  const proteinFromPantry = PROTEINS.find(p => pantryLower.some(n => n.includes(p)));
  const protein = proteinFromPantry || pick(PROTEINS, seed >> 3);

  const carbFromPantry = CARBS.find(c => pantryLower.some(n => n.includes(c)));
  const carb = carbFromPantry || pick(CARBS, seed >> 4);

  const vegFromPantry = VEGETABLES.filter(v => pantryLower.some(n => n.includes(v)));
  const veggies = vegFromPantry.length > 0 ? vegFromPantry.slice(0, 3) : pickMany(VEGETABLES, 3, seed >> 5);
  const herbs = pickMany(profile.herbs, 2, seed >> 6);
  const spices = pickMany(profile.spices, 2, seed >> 7);

  const ingredients: Ingredient[] = [
    { name: capitalize(protein), amount: '1', unit: 'lb' },
    { name: capitalize(carb), amount: '2', unit: 'cups' },
    ...veggies.slice(0, 3).map(v => ({ name: capitalize(v), amount: '1', unit: 'cup' })),
    ...herbs.map(h => ({ name: capitalize(h), amount: '2', unit: 'tbsp' })),
    ...spices.map(s => ({ name: capitalize(s), amount: '1', unit: 'tsp' })),
    { name: capitalize(profile.base), amount: '2', unit: 'tbsp' },
    { name: 'Salt and pepper', amount: 'to taste', unit: '' },
  ];

  // Deduplicate
  const seen = new Set<string>();
  const uniqueIngredients = ingredients.filter(i => {
    const key = i.name.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const instructions: Instruction[] = generateInstructions(template.method, protein, carb, veggies, herbs, spices, profile.base, template.cookTime);

  const totalCook = template.cookTime;
  const nutrition: Nutrition = calculateNutrition(protein, carb, veggies.length);

  const title = generateTitle(cuisine, template.name, protein);
  const description = generateDescription(cuisine, template.name, protein, veggies);

  return {
    id: crypto.randomUUID(),
    title,
    description,
    image_url: pick(IMAGE_POOL, seed >> 8),
    prep_time_min: 10,
    cook_time_min: totalCook,
    servings: 4,
    difficulty: totalCook <= 20 ? 'Easy' : totalCook <= 30 ? 'Medium' : 'Hard',
    cuisine,
    meal_type: 'dinner',
    ingredients: uniqueIngredients,
    instructions,
    nutrition,
    video_url: pick(VIDEO_POOL, seed >> 9),
    tags: [cuisine.toLowerCase(), protein, template.name.toLowerCase(), 'ai-generated'],
    source: 'ai',
    created_at: new Date().toISOString(),
  };
}

function generateInstructions(
  method: string, protein: string, carb: string, veggies: string[],
  herbs: string[], spices: string[], base: string, cookTime: number
): Instruction[] {
  const steps: Instruction[] = [];
  let stepNum = 1;

  steps.push({ step: stepNum++, text: `Prep all ingredients: dice ${protein}, chop ${veggies.join(', ')}, and mince ${herbs[0] || 'garlic'}.`, timer_min: 10 });

  if (method === 'stir-fry') {
    steps.push({ step: stepNum++, text: `Heat ${base} in a wok over high heat until shimmering.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Add ${protein} and stir-fry until browned and cooked through, about 5 minutes.`, timer_min: 5 });
    steps.push({ step: stepNum++, text: `Push protein aside, add ${veggies.join(', ')}, and stir-fry 3-4 minutes until crisp-tender.`, timer_min: 4 });
    steps.push({ step: stepNum++, text: `Sprinkle in ${spices.join(' and ')}, toss everything together, and add a splash of soy sauce.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Serve immediately over hot ${carb}, garnished with ${herbs[0] || 'scallions'}.`, timer_min: 1 });
  } else if (method === 'bowl') {
    steps.push({ step: stepNum++, text: `Cook ${carb} according to package directions. Fluff and set aside.`, timer_min: Math.min(cookTime, 18) });
    steps.push({ step: stepNum++, text: `Season ${protein} with ${spices.join(', ')}, salt, and pepper.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Sear ${protein} in ${base} over medium-high heat until golden and cooked through.`, timer_min: 8 });
    steps.push({ step: stepNum++, text: `Prepare vegetables: ${veggies.map(v => v === 'spinach' || v === 'kale' ? 'massage ' + v : 'slice ' + v).join(', ')}.`, timer_min: 3 });
    steps.push({ step: stepNum++, text: `Assemble bowls: ${carb} base, then protein and vegetables. Drizzle with dressing and top with ${herbs[0] || 'fresh herbs'}.`, timer_min: 2 });
  } else if (method === 'pasta') {
    steps.push({ step: stepNum++, text: `Bring a large pot of salted water to boil. Cook ${carb} until al dente.`, timer_min: 12 });
    steps.push({ step: stepNum++, text: `In a large skillet, heat ${base} and sauté ${veggies[0]} and ${veggies[1] || 'garlic'} until softened.`, timer_min: 5 });
    steps.push({ step: stepNum++, text: `Add ${protein} and cook through, breaking it apart if ground. Season with ${spices.join(' and ')}.`, timer_min: 6 });
    steps.push({ step: stepNum++, text: `Deglaze with a splash of pasta water, then toss in drained ${carb}.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Finish with ${herbs[0] || 'basil'} and a drizzle of olive oil. Serve immediately.`, timer_min: 1 });
  } else if (method === 'curry') {
    steps.push({ step: stepNum++, text: `Heat ${base} in a deep pan. Bloom ${spices.join(' and ')} for 30 seconds until fragrant.`, timer_min: 1 });
    steps.push({ step: stepNum++, text: `Add diced onion and cook until translucent, about 4 minutes.`, timer_min: 4 });
    steps.push({ step: stepNum++, text: `Add ${protein} and brown on all sides.`, timer_min: 5 });
    steps.push({ step: stepNum++, text: `Stir in ${veggies.join(', ')}, then pour in coconut milk or broth. Bring to a simmer.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Cover and simmer gently for 15 minutes until flavors meld and protein is tender.`, timer_min: 15 });
    steps.push({ step: stepNum++, text: `Finish with ${herbs[0] || 'cilantro'} and serve over ${carb}.`, timer_min: 1 });
  } else if (method === 'skillet') {
    steps.push({ step: stepNum++, text: `Pat ${protein} dry and season generously with ${spices.join(' and ')}, salt, and pepper.`, timer_min: 2 });
    steps.push({ step: stepNum++, text: `Heat ${base} in a cast-iron skillet over medium-high heat. Sear ${protein} 4-5 minutes per side.`, timer_min: 10 });
    steps.push({ step: stepNum++, text: `Remove protein. In the same pan, sauté ${veggies.join(', ')} until tender-crisp.`, timer_min: 5 });
    steps.push({ step: stepNum++, text: `Deglaze with broth or wine, scraping up browned bits. Reduce by half.`, timer_min: 3 });
    steps.push({ step: stepNum++, text: `Return protein to pan, spoon sauce over top, and garnish with ${herbs[0] || 'parsley'}. Serve with ${carb}.`, timer_min: 1 });
  } else {
    // sheet_pan
    steps.push({ step: stepNum++, text: `Preheat oven to 425F. Line a sheet pan with parchment.`, timer_min: 5 });
    steps.push({ step: stepNum++, text: `Toss ${protein} and ${veggies.join(', ')} with ${base}, ${spices.join(' and ')}, salt, and pepper.`, timer_min: 3 });
    steps.push({ step: stepNum++, text: `Arrange in a single layer on the sheet pan. Roast 20-25 minutes, flipping once.`, timer_min: 25 });
    steps.push({ step: stepNum++, text: `Check protein is cooked through and vegetables are caramelized.`, timer_min: 1 });
    steps.push({ step: stepNum++, text: `Serve over ${carb}, sprinkled with ${herbs[0] || 'fresh herbs'}.`, timer_min: 1 });
  }

  return steps;
}

function calculateNutrition(protein: string, carb: string, vegCount: number): Nutrition {
  const proteinCal = protein === 'tofu' || protein === 'chickpeas' ? 180 : 220;
  const carbCal = carb === 'quinoa' ? 220 : 200;
  const vegCal = vegCount * 35;
  const baseCal = 80; // oil and seasonings

  const calories = proteinCal + carbCal + vegCal + baseCal;
  return {
    calories,
    protein_g: protein === 'tofu' ? 20 : 35,
    carbs_g: Math.round(carbCal / 4),
    fat_g: Math.round(calories * 0.3 / 9),
    fiber_g: 4 + vegCount * 2,
    sodium_mg: 580,
    sugar_g: Math.min(8, vegCount * 2),
  };
}

function generateTitle(cuisine: string, dish: string, protein: string): string {
  const adjectives = ['Golden', 'Spiced', 'Herbed', 'Rustic', 'Zesty', 'Savory'];
  const seed = hashString(cuisine + dish + protein);
  const adj = adjectives[seed % adjectives.length];
  return `${adj} ${capitalize(protein)} ${dish}`;
}

function generateDescription(cuisine: string, dish: string, protein: string, veggies: string[]): string {
  return `An AI-generated ${cuisine.toLowerCase()} ${dish.toLowerCase()} featuring ${protein} and ${veggies.slice(0, 2).join(' and ')}. Balanced, flavorful, and ready in under 40 minutes.`;
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// Scan ingredients: matches free text to known food categories
export function classifyIngredient(name: string): { category: string; name: string } {
  const lower = name.toLowerCase().trim();
  const categoryMap: Record<string, string[]> = {
    Produce: ['tomato', 'onion', 'garlic', 'pepper', 'lettuce', 'spinach', 'kale', 'carrot', 'potato', 'broccoli', 'avocado', 'lemon', 'lime', 'apple', 'banana', 'berry', 'mango', 'cucumber', 'zucchini', 'asparagus', 'mushroom', 'ginger', 'cilantro', 'basil', 'parsley', 'mint', 'thyme', 'rosemary', 'shallot', 'leek'],
    Dairy: ['milk', 'cheese', 'butter', 'yogurt', 'cream', 'feta', 'parmesan', 'mozzarella', 'egg'],
    Meat: ['chicken', 'beef', 'pork', 'bacon', 'turkey', 'sausage', 'shrimp', 'salmon', 'tuna', 'fish', 'steak', 'ground', 'pancetta'],
    Pantry: ['rice', 'pasta', 'quinoa', 'flour', 'sugar', 'oil', 'vinegar', 'soy sauce', 'tahini', 'honey', 'oats', 'beans', 'chickpeas', 'lentils', 'tomato paste', 'coconut milk', 'bread crumbs', 'nuts', 'almond'],
    Frozen: ['frozen', 'ice', 'peas'],
    Spices: ['salt', 'pepper', 'paprika', 'cumin', 'turmeric', 'chili', 'oregano', 'cinnamon', 'coriander', 'italian seasoning'],
    Bakery: ['bread', 'sourdough', 'baguette', 'tortilla', 'pita', 'bun', 'roll', 'dough'],
    Beverages: ['water', 'juice', 'wine', 'beer', 'coffee', 'tea', 'broth', 'stock'],
  };

  for (const [category, keywords] of Object.entries(categoryMap)) {
    if (keywords.some(kw => lower.includes(kw))) {
      return { category, name: capitalize(lower) };
    }
  }
  return { category: 'Other', name: capitalize(lower) };
}
