import type { Nutrition } from '../lib/supabase';

type NutritionFactsProps = {
  nutrition: Nutrition;
  servings?: number;
};

export function NutritionFacts({ nutrition, servings = 1 }: NutritionFactsProps) {
  const data = {
    calories: Math.round(nutrition.calories / servings),
    protein_g: Math.round(nutrition.protein_g / servings),
    carbs_g: Math.round(nutrition.carbs_g / servings),
    fat_g: Math.round(nutrition.fat_g / servings),
    fiber_g: Math.round(nutrition.fiber_g / servings),
    sodium_mg: Math.round(nutrition.sodium_mg / servings),
    sugar_g: Math.round(nutrition.sugar_g / servings),
  };

  const macros = [
    { label: 'Protein', value: data.protein_g, unit: 'g', color: 'bg-primary-500', textColor: 'text-primary-700', pct: Math.round((data.protein_g * 4 / data.calories) * 100) },
    { label: 'Carbs', value: data.carbs_g, unit: 'g', color: 'bg-secondary-500', textColor: 'text-secondary-700', pct: Math.round((data.carbs_g * 4 / data.calories) * 100) },
    { label: 'Fat', value: data.fat_g, unit: 'g', color: 'bg-accent-500', textColor: 'text-accent-700', pct: Math.round((data.fat_g * 9 / data.calories) * 100) },
  ];

  const micros = [
    { label: 'Fiber', value: data.fiber_g, unit: 'g', icon: '🥬' },
    { label: 'Sugar', value: data.sugar_g, unit: 'g', icon: '🍯' },
    { label: 'Sodium', value: data.sodium_mg, unit: 'mg', icon: '🧂' },
  ];

  return (
    <div className="bg-white rounded-2xl border border-neutral-200 overflow-hidden">
      <div className="px-5 py-4 bg-neutral-50 border-b border-neutral-200">
        <div className="flex items-baseline justify-between">
          <h3 className="font-display text-lg font-bold text-neutral-900">Nutrition Facts</h3>
          <span className="text-xs text-neutral-400">per serving</span>
        </div>
      </div>

      <div className="p-5">
        {/* Calories highlight */}
        <div className="flex items-end justify-between mb-5 pb-5 border-b-2 border-neutral-900">
          <div>
            <div className="text-xs font-medium text-neutral-500 uppercase tracking-wide">Calories</div>
            <div className="text-4xl font-bold text-neutral-900 font-display">{data.calories}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-neutral-400">% Daily Value*</div>
            <div className="text-sm text-neutral-500">per serving</div>
          </div>
        </div>

        {/* Macros with bars */}
        <div className="space-y-4 mb-5">
          {macros.map(m => (
            <div key={m.label}>
              <div className="flex items-baseline justify-between mb-1.5">
                <span className="text-sm font-medium text-neutral-700">{m.label}</span>
                <span className="text-sm font-semibold text-neutral-900">
                  {m.value}<span className="text-neutral-400 font-normal">{m.unit}</span>
                  <span className={`ml-2 text-xs ${m.textColor}`}>{m.pct}%</span>
                </span>
              </div>
              <div className="h-2 rounded-full bg-neutral-100 overflow-hidden">
                <div
                  className={`h-full rounded-full ${m.color} transition-all duration-700`}
                  style={{ width: `${Math.min(m.pct, 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Micros grid */}
        <div className="grid grid-cols-3 gap-3 pt-4 border-t border-neutral-200">
          {micros.map(m => (
            <div key={m.label} className="text-center">
              <div className="text-xs text-neutral-400 mb-0.5">{m.label}</div>
              <div className="text-lg font-semibold text-neutral-800">
                {m.value}<span className="text-xs font-normal text-neutral-400">{m.unit}</span>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-4 text-xs text-neutral-400 leading-relaxed">
          * Percent Daily Values based on a 2,000 calorie diet. Values are estimates.
        </p>
      </div>
    </div>
  );
}
