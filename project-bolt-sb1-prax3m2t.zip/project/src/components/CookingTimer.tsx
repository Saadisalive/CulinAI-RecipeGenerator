import { useEffect, useRef, useState, useCallback } from 'react';
import { Play, Pause, RotateCcw, Bell, X, Clock } from 'lucide-react';

type CookingTimerProps = {
  initialMinutes?: number;
  label?: string;
  onClose?: () => void;
};

export function CookingTimer({ initialMinutes = 5, label = 'Cooking Timer', onClose }: CookingTimerProps) {
  const [totalSeconds, setTotalSeconds] = useState(initialMinutes * 60);
  const [remaining, setRemaining] = useState(initialMinutes * 60);
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    setTotalSeconds(initialMinutes * 60);
    setRemaining(initialMinutes * 60);
    setRunning(false);
    setFinished(false);
  }, [initialMinutes]);

  useEffect(() => {
    if (running && remaining > 0) {
      intervalRef.current = setInterval(() => {
        setRemaining(prev => {
          if (prev <= 1) {
            setRunning(false);
            setFinished(true);
            playBeep();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running, remaining]);

  const playBeep = useCallback(() => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      for (let i = 0; i < 3; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.4);
        gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + i * 0.4 + 0.05);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + i * 0.4 + 0.2);
        osc.start(ctx.currentTime + i * 0.4);
        osc.stop(ctx.currentTime + i * 0.4 + 0.25);
      }
    } catch {
      // AudioContext not available
    }
  }, []);

  const mins = Math.floor(remaining / 60);
  const secs = remaining % 60;
  const progress = totalSeconds > 0 ? ((totalSeconds - remaining) / totalSeconds) * 100 : 0;

  const adjustTime = (delta: number) => {
    const newTotal = Math.max(60, totalSeconds + delta * 60);
    setTotalSeconds(newTotal);
    setRemaining(newTotal);
    setFinished(false);
  };

  return (
    <div className={`rounded-2xl p-5 transition-colors ${
      finished ? 'bg-success-50 border-2 border-success-300 animate-pulse-slow' :
      running ? 'bg-primary-50 border-2 border-primary-200' :
      'bg-white border border-neutral-200'
    }`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-primary-600" />
          <span className="text-sm font-semibold text-neutral-800">{label}</span>
        </div>
        {onClose && (
          <button onClick={onClose} className="p-1 rounded text-neutral-400 hover:text-neutral-700">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="flex justify-center mb-4">
        <div className="relative w-36 h-36">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="54" fill="none" stroke="#e7e5e4" strokeWidth="8" />
            <circle
              cx="60" cy="60" r="54" fill="none"
              stroke={finished ? '#22c55e' : '#ed6f13'}
              strokeWidth="8" strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 54}
              strokeDashoffset={2 * Math.PI * 54 * (1 - progress / 100)}
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {finished ? (
              <Bell className="w-8 h-8 text-success-500 animate-bounce-subtle" />
            ) : (
              <>
                <span className="font-mono text-2xl font-bold text-neutral-900 tabular-nums">
                  {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
                </span>
                <span className="text-xs text-neutral-400 mt-1">remaining</span>
              </>
            )}
          </div>
        </div>
      </div>

      {finished && (
        <div className="text-center mb-3 text-success-700 font-semibold text-sm animate-fade-in">
          Timer finished — your food is ready!
        </div>
      )}

      <div className="flex items-center justify-center gap-2">
        <button
          onClick={() => adjustTime(-5)}
          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-neutral-100 text-neutral-600 hover:bg-neutral-200 transition-colors disabled:opacity-50"
          disabled={running}
        >
          -5 min
        </button>
        <button
          onClick={() => { setRunning(!running); setFinished(false); }}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-all ${
            running ? 'bg-neutral-700 hover:bg-neutral-800' : 'bg-gradient-warm hover:shadow-glow'
          }`}
        >
          {running ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          {running ? 'Pause' : 'Start'}
        </button>
        <button
          onClick={() => adjustTime(5)}
          className="px-3 py-1.5 rounded-lg text-sm font-medium bg-neutral-100 text-neutral-600 hover:bg-neutral-200 transition-colors disabled:opacity-50"
          disabled={running}
        >
          +5 min
        </button>
        <button
          onClick={() => { setRemaining(totalSeconds); setRunning(false); setFinished(false); }}
          className="p-2 rounded-lg text-neutral-500 hover:bg-neutral-100 hover:text-neutral-700 transition-colors"
          title="Reset"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
