import type { Recipe } from '../lib/supabase';
import { Clock, Users, ChefHat, Flame, Sparkles } from 'lucide-react';

type RecipeCardProps = {
  recipe: Recipe;
  onClick: () => void;
  onAddToPlan?: () => void;
  compact?: boolean;
};

export function RecipeCard({ recipe, onClick, onAddToPlan, compact = false }: RecipeCardProps) {
  const totalTime = recipe.prep_time_min + recipe.cook_time_min;
  const isAI = recipe.source === 'ai';

  return (
    <article
      onClick={onClick}
      className="group cursor-pointer bg-white rounded-2xl overflow-hidden shadow-soft hover:shadow-large transition-all duration-300 hover:-translate-y-1"
    >
      <div className={`relative overflow-hidden ${compact ? 'h-40' : 'h-52'}`}>
        {recipe.image_url ? (
          <img
            src={recipe.image_url}
            alt={recipe.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full bg-gradient-warm flex items-center justify-center">
            <ChefHat className="w-12 h-12 text-white/60" />
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          {isAI && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-warm text-white shadow-soft">
              <Sparkles className="w-3 h-3" />
              AI
            </span>
          )}
          <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-white/90 text-neutral-800 backdrop-blur-sm">
            {recipe.cuisine}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
            recipe.difficulty === 'Easy' ? 'bg-success-100 text-success-700' :
            recipe.difficulty === 'Medium' ? 'bg-warning-100 text-warning-700' :
            'bg-error-100 text-error-700'
          }`}>
            {recipe.difficulty}
          </span>
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-display text-lg font-bold text-neutral-900 leading-snug group-hover:text-primary-600 transition-colors line-clamp-2">
          {recipe.title}
        </h3>
        {!compact && (
          <p className="mt-1.5 text-sm text-neutral-500 line-clamp-2">{recipe.description}</p>
        )}

        <div className="mt-3 flex items-center gap-4 text-xs text-neutral-500">
          <span className="inline-flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-primary-500" />
            {totalTime} min
          </span>
          <span className="inline-flex items-center gap-1">
            <Users className="w-3.5 h-3.5 text-secondary-500" />
            {recipe.servings} serv
          </span>
          <span className="inline-flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-accent-500" />
            {recipe.nutrition?.calories || 0} cal
          </span>
        </div>

        {onAddToPlan && (
          <button
            onClick={(e) => { e.stopPropagation(); onAddToPlan(); }}
            className="mt-3 w-full py-2 rounded-lg text-sm font-medium bg-neutral-100 text-neutral-700 hover:bg-primary-50 hover:text-primary-700 transition-colors"
          >
            Add to Meal Plan
          </button>
        )}
      </div>
    </article>
  );
}
