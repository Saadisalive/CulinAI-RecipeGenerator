import { useEffect, useState, useCallback } from 'react';

export type Toast = {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
};

let listeners: ((toasts: Toast[]) => void)[] = [];
let toasts: Toast[] = [];

function emit() {
  listeners.forEach(l => l(toasts));
}

export function showToast(message: string, type: Toast['type'] = 'success') {
  const id = crypto.randomUUID();
  toasts = [...toasts, { id, message, type }];
  emit();
  setTimeout(() => {
    toasts = toasts.filter(t => t.id !== id);
    emit();
  }, 3000);
}

export function useToasts() {
  const [currentToasts, setCurrentToasts] = useState<Toast[]>(toasts);

  useEffect(() => {
    listeners.push(setCurrentToasts);
    return () => {
      listeners = listeners.filter(l => l !== setCurrentToasts);
    };
  }, []);

  const remove = useCallback((id: string) => {
    toasts = toasts.filter(t => t.id !== id);
    emit();
  }, []);

  return { toasts: currentToasts, remove };
}
