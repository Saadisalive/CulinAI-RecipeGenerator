import { useState, useEffect, useCallback } from 'react';
import { ChefHat, Home, ScanLine, Sparkles, Calendar, ShoppingCart, Timer, X, Menu } from 'lucide-react';
import { Dashboard } from './views/Dashboard';
import { ScanIngredients } from './views/ScanIngredients';
import { RecipeGenerator } from './views/RecipeGenerator';
import { RecipeDetail } from './views/RecipeDetail';
import { MealPlanner } from './views/MealPlanner';
import { GroceryList } from './views/GroceryList';
import { CookingTimers } from './views/CookingTimers';
import { useToasts } from './components/Toast';
import type { Recipe } from './lib/supabase';

type View = 'home' | 'scan' | 'generate' | 'planner' | 'grocery' | 'timers' | 'recipe';

const NAV_ITEMS: { id: View; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Dashboard', icon: Home },
  { id: 'scan', label: 'Scan Ingredients', icon: ScanLine },
  { id: 'generate', label: 'AI Recipe Generator', icon: Sparkles },
  { id: 'planner', label: 'Meal Planner', icon: Calendar },
  { id: 'grocery', label: 'Grocery List', icon: ShoppingCart },
  { id: 'timers', label: 'Cooking Timers', icon: Timer },
];

export default function App() {
  const [view, setView] = useState<View>('home');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { toasts } = useToasts();

  const navigate = useCallback((v: View) => {
    setView(v);
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openRecipe = useCallback((recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setView('recipe');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const handleNav = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.view) navigate(detail.view as View);
    };
    window.addEventListener('app-navigate', handleNav as EventListener);
    return () => window.removeEventListener('app-navigate', handleNav as EventListener);
  }, [navigate]);

  const navItem = (item: { id: View; label: string; icon: typeof Home }) => {
    const Icon = item.icon;
    const active = view === item.id || (item.id === 'generate' && view === 'recipe' && selectedRecipe?.source === 'ai');
    return (
      <button
        key={item.id}
        onClick={() => navigate(item.id)}
        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
          active
            ? 'bg-gradient-warm text-white shadow-soft'
            : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
        }`}
      >
        <Icon className={`w-5 h-5 ${active ? 'text-white' : 'text-neutral-400'}`} />
        <span>{item.label}</span>
      </button>
    );
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Sidebar — desktop */}
      <aside className="hidden lg:flex flex-col w-64 fixed inset-y-0 left-0 bg-white border-r border-neutral-200 z-30">
        <div className="px-6 py-6">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-warm flex items-center justify-center shadow-glow">
              <ChefHat className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold text-neutral-900 leading-none">CulinAI</h1>
              <p className="text-xs text-neutral-400 mt-0.5">Smart Cooking</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-3 space-y-1">
          {NAV_ITEMS.map(navItem)}
        </nav>
        <div className="p-4 mx-3 mb-4 rounded-xl bg-gradient-to-br from-primary-50 to-accent-50 border border-primary-100">
          <div className="flex items-center gap-2 mb-1.5">
            <Sparkles className="w-4 h-4 text-primary-600" />
            <span className="text-sm font-semibold text-primary-900">Pro Tip</span>
          </div>
          <p className="text-xs text-primary-700 leading-relaxed">
            Scan your ingredients first, then let AI generate recipes from what you have.
          </p>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-neutral-900/40 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-large flex flex-col animate-slide-down">
            <div className="flex items-center justify-between px-6 py-6">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-warm flex items-center justify-center">
                  <ChefHat className="w-5 h-5 text-white" />
                </div>
                <h1 className="font-display text-xl font-bold text-neutral-900">CulinAI</h1>
              </div>
              <button onClick={() => setSidebarOpen(false)} className="p-2 rounded-lg hover:bg-neutral-100">
                <X className="w-5 h-5 text-neutral-500" />
              </button>
            </div>
            <nav className="flex-1 px-3 space-y-1">
              {NAV_ITEMS.map(navItem)}
            </nav>
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 lg:ml-64 min-h-screen flex flex-col">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-20 glass border-b border-neutral-200 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-warm flex items-center justify-center">
              <ChefHat className="w-4 h-4 text-white" />
            </div>
            <span className="font-display text-lg font-bold text-neutral-900">CulinAI</span>
          </div>
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-neutral-100">
            <Menu className="w-5 h-5 text-neutral-700" />
          </button>
        </header>

        <main className="flex-1 p-4 lg:p-8">
          {view === 'home' && <Dashboard onOpenRecipe={openRecipe} onNavigate={navigate} />}
          {view === 'scan' && <ScanIngredients onNavigate={navigate} />}
          {view === 'generate' && <RecipeGenerator onOpenRecipe={openRecipe} />}
          {view === 'planner' && <MealPlanner onOpenRecipe={openRecipe} />}
          {view === 'grocery' && <GroceryList />}
          {view === 'timers' && <CookingTimers />}
          {view === 'recipe' && selectedRecipe && (
            <RecipeDetail
              recipe={selectedRecipe}
              onBack={() => navigate('home')}
              onOpenRecipe={openRecipe}
            />
          )}
        </main>
      </div>

      {/* Toast container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`pointer-events-auto px-4 py-3 rounded-xl shadow-large animate-slide-up flex items-center gap-2 ${
              t.type === 'success' ? 'bg-success-600 text-white' :
              t.type === 'error' ? 'bg-error-600 text-white' :
              'bg-neutral-800 text-white'
            }`}
          >
            <span className="text-sm font-medium">{t.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
