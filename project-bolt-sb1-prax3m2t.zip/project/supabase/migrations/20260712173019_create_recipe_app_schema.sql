/*
# Recipe & Cooking App — Initial Schema

## Overview
Creates the core data model for an AI Recipe & Cooking App. Single-tenant (no auth) —
all data is shared across the single user of this app.

## New Tables

### recipes
Stores curated and AI-generated recipes.
- id (uuid, PK)
- title (text, not null)
- description (text)
- image_url (text) — Pexels stock photo URL
- prep_time_min (int, default 15)
- cook_time_min (int, default 30)
- servings (int, default 4)
- difficulty (text: Easy/Medium/Hard, default Medium)
- cuisine (text, default Italian)
- meal_type (text: breakfast/lunch/dinner/snack/dessert, default dinner)
- ingredients (jsonb array of {name, amount, unit})
- instructions (jsonb array of {step, text, timer_min})
- nutrition (jsonb: calories, protein_g, carbs_g, fat_g, fiber_g, sodium_mg, sugar_g)
- video_url (text) — YouTube embed URL
- tags (text[])
- source (text: curated/ai, default curated)
- created_at (timestamptz)

### pantry_items
Ingredients the user has on hand (from scanning or manual entry).
- id (uuid, PK)
- name (text, not null)
- quantity (text)
- unit (text)
- category (text: Produce/Dairy/Meat/Pantry/Frozen/Spices/Bakery/Beverages/Other)
- image_url (text)
- notes (text)
- created_at (timestamptz)

### meal_plans
Weekly meal planning entries.
- id (uuid, PK)
- plan_date (date, not null)
- meal_type (text: breakfast/lunch/dinner/snack)
- recipe_id (uuid, FK → recipes, ON DELETE CASCADE)
- servings (int, default 1)
- created_at (timestamptz)

### grocery_items
Grocery list items, optionally linked to a recipe.
- id (uuid, PK)
- name (text, not null)
- quantity (text)
- unit (text)
- category (text, same categories as pantry)
- checked (boolean, default false)
- recipe_id (uuid, FK → recipes, ON DELETE SET NULL)
- created_at (timestamptz)

## Security
- RLS enabled on all tables.
- All policies use TO anon, authenticated (single-tenant, no auth screen).
- Full CRUD allowed for anon + authenticated since data is intentionally shared.
*/

CREATE TABLE IF NOT EXISTS recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  image_url text,
  prep_time_min int NOT NULL DEFAULT 15,
  cook_time_min int NOT NULL DEFAULT 30,
  servings int NOT NULL DEFAULT 4,
  difficulty text NOT NULL DEFAULT 'Medium',
  cuisine text NOT NULL DEFAULT 'Italian',
  meal_type text NOT NULL DEFAULT 'dinner',
  ingredients jsonb NOT NULL DEFAULT '[]'::jsonb,
  instructions jsonb NOT NULL DEFAULT '[]'::jsonb,
  nutrition jsonb NOT NULL DEFAULT '{}'::jsonb,
  video_url text,
  tags text[] NOT NULL DEFAULT '{}',
  source text NOT NULL DEFAULT 'curated',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pantry_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  quantity text,
  unit text,
  category text NOT NULL DEFAULT 'Other',
  image_url text,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meal_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_date date NOT NULL,
  meal_type text NOT NULL,
  recipe_id uuid REFERENCES recipes(id) ON DELETE CASCADE,
  servings int NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS grocery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  quantity text,
  unit text,
  category text NOT NULL DEFAULT 'Other',
  checked boolean NOT NULL DEFAULT false,
  recipe_id uuid REFERENCES recipes(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;
ALTER TABLE pantry_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE meal_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE grocery_items ENABLE ROW LEVEL SECURITY;

-- recipes policies
DROP POLICY IF EXISTS "anon_select_recipes" ON recipes;
CREATE POLICY "anon_select_recipes" ON recipes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_recipes" ON recipes;
CREATE POLICY "anon_insert_recipes" ON recipes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_recipes" ON recipes;
CREATE POLICY "anon_update_recipes" ON recipes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_recipes" ON recipes;
CREATE POLICY "anon_delete_recipes" ON recipes FOR DELETE
  TO anon, authenticated USING (true);

-- pantry_items policies
DROP POLICY IF EXISTS "anon_select_pantry" ON pantry_items;
CREATE POLICY "anon_select_pantry" ON pantry_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_pantry" ON pantry_items;
CREATE POLICY "anon_insert_pantry" ON pantry_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_pantry" ON pantry_items;
CREATE POLICY "anon_update_pantry" ON pantry_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_pantry" ON pantry_items;
CREATE POLICY "anon_delete_pantry" ON pantry_items FOR DELETE
  TO anon, authenticated USING (true);

-- meal_plans policies
DROP POLICY IF EXISTS "anon_select_meal_plans" ON meal_plans;
CREATE POLICY "anon_select_meal_plans" ON meal_plans FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_meal_plans" ON meal_plans;
CREATE POLICY "anon_insert_meal_plans" ON meal_plans FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_meal_plans" ON meal_plans;
CREATE POLICY "anon_update_meal_plans" ON meal_plans FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_meal_plans" ON meal_plans;
CREATE POLICY "anon_delete_meal_plans" ON meal_plans FOR DELETE
  TO anon, authenticated USING (true);

-- grocery_items policies
DROP POLICY IF EXISTS "anon_select_grocery" ON grocery_items;
CREATE POLICY "anon_select_grocery" ON grocery_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_grocery" ON grocery_items;
CREATE POLICY "anon_insert_grocery" ON grocery_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_grocery" ON grocery_items;
CREATE POLICY "anon_update_grocery" ON grocery_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_grocery" ON grocery_items;
CREATE POLICY "anon_delete_grocery" ON grocery_items FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_recipes_meal_type ON recipes(meal_type);
CREATE INDEX IF NOT EXISTS idx_recipes_cuisine ON recipes(cuisine);
CREATE INDEX IF NOT EXISTS idx_meal_plans_date ON meal_plans(plan_date);
CREATE INDEX IF NOT EXISTS idx_grocery_checked ON grocery_items(checked);
CREATE INDEX IF NOT EXISTS idx_pantry_category ON pantry_items(category);
